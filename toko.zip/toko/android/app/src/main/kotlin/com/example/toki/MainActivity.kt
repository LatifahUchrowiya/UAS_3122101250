package com.example.toki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
